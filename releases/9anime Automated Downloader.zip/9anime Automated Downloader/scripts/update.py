import requests, zipfile, socket
import os, io, sys, subprocess, datetime, traceback
import win32api, win32con, win32gui
import threading



def logs(e):
    # Create a filename based on the current date and time
    now = datetime.datetime.now()
    filename = f"others/logs/log__{now.strftime('%d-%m-%Y__%H-%M-%S')}.txt"
    os.makedirs("others/logs", exist_ok=True)

    # Open the file and write log data
    with open(filename, "w") as f:
        f.write(f"\nOrigin: update.py\n_______________________________________\n\n{e}")

try:
    # Get the current version number from command line arguments
    current_version_number = sys.argv[1]

    # URL of the JSON file containing the latest version information
    VERSION_URL = "https://market-app-473c6-default-rtdb.asia-southeast1.firebasedatabase.app/9anime_Automated_Downloader.json"
    # Get the full path to the current directory
    APP_PARENT_FOLDER = os.path.dirname(os.getcwd())

    def show_updating_box():
        win32api.MessageBox(0, 'New Update Available.\n\nUpdating...', 'Updating...', win32con.MB_OK | win32con.MB_ICONINFORMATION | 0x40000)

    def show_update_checker_box():
        win32api.MessageBox(0, 'Checking for Update. Please Wait...', 'Update Checker', win32con.MB_OK | win32con.MB_ICONINFORMATION | 0x40000)

    def is_connected():
        try:
            # Connect to Google DNS (8.8.8.8) on port 53
            socket.create_connection(("8.8.8.8", 53))
            return True
        except OSError:
            pass
        return False

    if is_connected():
        thread = threading.Thread(target=show_update_checker_box)
        thread.start()

        # Retrieve the latest version information
        response = requests.get(VERSION_URL)
        if response.status_code == 200:
            # Close the update checker box
            hwnd = win32gui.FindWindow(0, 'Update Checker')
            win32gui.SendMessage(hwnd, win32con.WM_CLOSE, 0, 0)
            version_data = response.json()

            # Check if an update is available
            if version_data['version'] != current_version_number:
                # update the updater view
                thread = threading.Thread(target=show_updating_box)
                thread.start()
                # Download and extract the updated files
                response = requests.get(version_data['download_url'], timeout=100)
                hwnd = win32gui.FindWindow(0, 'Updating...')
                win32gui.SendMessage(hwnd, win32con.WM_CLOSE, 0, 0)

                if response.headers['content-type'] == 'application/zip':
                    with zipfile.ZipFile(io.BytesIO(response.content)) as zip_file:
                        zip_file.extractall(APP_PARENT_FOLDER)
                    subprocess.Popen('"9anime Automated Downloader.exe"')
                    win32api.MessageBox(0, "9anime Automated Downloader has been updated to the latest version.", "Update Complete", win32con.MB_OK | win32con.MB_ICONINFORMATION | 0x40000)
                else:
                    subprocess.Popen('"9anime Automated Downloader.exe"')
                    win32api.MessageBox(0, "An unexpected error occurred during update check! Please try again later.", "Oops, An error occurred", win32con.MB_OK | win32con.MB_ICONSTOP | 0x40000)
            else:
                subprocess.Popen('"9anime Automated Downloader.exe"')
                win32api.MessageBox(0, "9anime Automated Downloader is already up to date.", "Already Up To Date", win32con.MB_OK | win32con.MB_ICONINFORMATION | 0x40000)
        else:
            # When failed to get version data, display error message
            subprocess.Popen('"9anime Automated Downloader.exe"')
            win32api.MessageBox(0, "Failed to check for update.", "Oops, An error occurred", win32con.MB_OK | win32con.MB_ICONSTOP | 0x40000)
        thread.join()
    else:
        subprocess.Popen('"9anime Automated Downloader.exe"')
        win32api.MessageBox(0, "Internet connection not available. Failed to check for update.", "No Internet", win32con.MB_OK | win32con.MB_ICONSTOP | 0x40000)

except Exception as e: 
    logs(traceback.format_exc())
    # Close the update window
    hwnd = win32gui.FindWindow(0, 'Update Checker')
    win32gui.SendMessage(hwnd, win32con.WM_CLOSE, 0, 0)
    hwnd = win32gui.FindWindow(0, 'Updating...')
    win32gui.SendMessage(hwnd, win32con.WM_CLOSE, 0, 0)
    subprocess.Popen('"9anime Automated Downloader.exe"')
    win32api.MessageBox(0, f"An unexpected error occurred during update check! Please try again later.\n\n{e}", "Oops, An error occurred", win32con.MB_OK | win32con.MB_ICONSTOP)


