import os, re, sys, datetime, traceback
import win32api, win32con
import PySimpleGUI as sg


def logs(e):
    # Create a filename based on the current date and time
    now = datetime.datetime.now()
    filename = f"others/logs/log__{now.strftime('%d-%m-%Y__%H-%M-%S')}.txt"
    os.makedirs("others/logs", exist_ok=True)

    # Open the file and write log data
    with open(filename, "w") as f:
        f.write(f"\nOrigin: update.py\n_______________________________________\n\n{e}")

try:
    # Get the directory path from the argument
    directory = sys.argv[1]

    # Check if the directory path is valid
    if not os.path.isdir(directory):
        win32api.MessageBox(0, f'Error: "{directory}" is not a valid directory path.', "Not Found", win32con.MB_OK | win32con.MB_ICONEXCLAMATION)
        sys.exit()

    prefix = "Episode_"
    extension = ".ts"
    # Set up the regular expression pattern to match the file names
    pattern = r"^(.+?)(_?(\d+))?\.(ts)$"
    # Get all the file names in the directory with the ".ts" extension
    files = [f for f in os.listdir(directory) if os.path.isfile(os.path.join(directory, f)) and f.endswith(extension)]
    # Sort the file names by the number suffix (if present)
    files.sort(key=lambda x: int(re.search(pattern, x).group(3) or 0))


    # GUI Theme
    sg.theme('DarkBlue1')
    sg.theme_input_background_color('#161b22')

    # Create the PySimpleGUI layout
    layout = [
        [sg.Text("Note: Only (.ts) file extension is renamed")],
    ]

    # Add a message element if there are no .ts files
    if not files:
        layout.append([sg.Text("No (.ts) Extension File found.", font=('Helvetica', 20), text_color='red', pad=(0, 50))])
    else:
        files_list = []
        files_list.extend(files)
        files_list = ["      " + file_name + "      " for file_name in files_list]
        files_list.insert(0, "")
        files_list.append("")
        print(files_list)
        layout.append([sg.Text(f"{len(files)} files found.", font=('Helvetica', 16), text_color='#05ff12', pad=((0, 0), (8, 15)))])
        layout.append([sg.Listbox(values=files_list, size=(700, 15),horizontal_scroll = True, font=('Helvetica', 12), key="-FILE LIST-")])
        layout.append([sg.Button('Rename', size=(20, 2), font=('Helvetica', 14), pad=((0, 0), (25, 5)), button_color=("white", '#731cff'))])


    # Create the PySimpleGUI window
    window = sg.Window("Rename Files", layout, size=(800, 500), element_justification='center')

    # Event loop to process events and get values from inputs
    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED:
            break
        if event == "Rename":
            # Loop through each file in the directory
            for i, file in enumerate(files):
                # Check if the file name matches the pattern
                match = re.match(pattern, file)
                if match:
                    # Get the base file name and the optional number suffix
                    base_name = match.group(1)
                    suffix = match.group(3)
                    # Create the new file name
                    new_file_name = prefix + str(i+1) + extension
                    # Rename the file
                    os.rename(os.path.join(directory, file), os.path.join(directory, new_file_name))
            window.close()
            win32api.MessageBox(0, "Files renamed successfully!", "Success", win32con.MB_OK | win32con.MB_ICONINFORMATION)

    # Close the window
    window.close()

except Exception as e: 
    logs(traceback.format_exc())
    win32api.MessageBox(0, f"An unexpected error occurred! Please try again later.\n\n{e}", "Oops, An error occurred", win32con.MB_OK | win32con.MB_ICONSTOP)


