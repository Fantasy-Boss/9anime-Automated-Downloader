import pyautogui as pg
import time, keyboard, cv2, datetime, traceback
import numpy as np
import asyncio, os, json
import pygetwindow as gw
import win32api, win32con


# Get the full path to the current directory
current_dir = os.getcwd()
# Path to the settings JSON file
settings_path = os.path.join(current_dir, "others/settings.json")
# Load the settings from the JSON file
with open(settings_path, "r") as f:
    settings = json.load(f)


async def switch():
    # Try to switch to Google Chrome
    if settings['browser'] == 'Google Chrome':
        chrome_win = gw.getWindowsWithTitle('Google Chrome')
        if chrome_win:
            print('Google Chrome Found.')
            chrome_win[0].activate()
        else:
            # If Chrome is not found, switch to Firefox
            print('Google Chrome Not Found.')
            firefox_win = gw.getWindowsWithTitle('Mozilla Firefox')
            if firefox_win:
                print('Mozilla Firefox Found.')
                firefox_win[0].activate()
            else:
                win32api.MessageBox(0, "Neither Google Chrome nor Mozilla Firefox found.", "Browser Not Found", win32con.MB_OK | win32con.MB_ICONEXCLAMATION)
                return False
    else:
        firefox_win = gw.getWindowsWithTitle('Mozilla Firefox')
        if firefox_win:
            print('Mozilla Firefox Found.')
            firefox_win[0].activate()
        else:
            # If Firefox is not found, switch to Chrome
            print('Mozilla Firefox Not Found.')
            chrome_win = gw.getWindowsWithTitle('Google Chrome')
            if chrome_win:
                print('Google Chrome Found.')
                chrome_win[0].activate()
            else:
                win32api.MessageBox(0, "Neither Google Chrome nor Mozilla Firefox found.", "Browser Not Found", win32con.MB_OK | win32con.MB_ICONEXCLAMATION)
                return False
    return True


async def fixView():
    # Determine the size of the screen
    screen_width, screen_height = pg.size()
    # Scroll up until we reach the top of the page
    i = 0
    while i < 10:
        # Scroll up by one "click"
        i += 1
        pg.scroll(1000)
        # Check if we've reached the top of the page
        if pg.position()[1] == 0:
            break
    # Adjust the view
    while True:
        next_template = cv2.imread('assets/next.png', cv2.IMREAD_GRAYSCALE)
        screenshot = np.array(pg.screenshot())
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        next_result = cv2.matchTemplate(gray_screenshot, next_template, cv2.TM_CCOEFF_NORMED)
        next_min_val, next_max_val, next_min_loc, next_max_loc = cv2.minMaxLoc(next_result)
        if next_max_val >= 0.8:
            print("View Fixed")
            pg.scroll(-20)
            return True
        else:
            pg.scroll(-40)


async def play():
    start_time = time.time()
    while True:
        play_template = cv2.imread('assets/play.png', cv2.IMREAD_GRAYSCALE)
        screenshot = np.array(pg.screenshot())
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        play_result = cv2.matchTemplate(gray_screenshot, play_template, cv2.TM_CCOEFF_NORMED)
        play_min_val, play_max_val, play_min_loc, play_max_loc = cv2.minMaxLoc(play_result)
        if play_max_val >= 0.8:
            x, y = play_max_loc
            w, h = play_template.shape[::-1]
            x += w // 2
            y += h // 2
            print("Play Button Found")
            pg.click(x, y)
            time.sleep(1)
            return True     
        else:
            time.sleep(0.1)
            elapsed_time = time.time() - start_time
            if elapsed_time >= 10:
                print("Play Button Not Found")
                print("Elapsed time exceeded 10 seconds, exiting the loop")
                return False # exit the loop


async def idm():
    start_time = time.time()
    while True:
        idm_template = cv2.imread('assets/idm.png', cv2.IMREAD_GRAYSCALE)
        idm_dim_template = cv2.imread('assets/idm_dim.png', cv2.IMREAD_GRAYSCALE)
        screenshot = np.array(pg.screenshot())
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        idm_result = cv2.matchTemplate(gray_screenshot, idm_template, cv2.TM_CCOEFF_NORMED)
        idm_dim_result = cv2.matchTemplate(gray_screenshot, idm_dim_template, cv2.TM_CCOEFF_NORMED)
        idm_min_val, idm_max_val, idm_min_loc, idm_max_loc = cv2.minMaxLoc(idm_result)
        idm_dim_min_val, idm_dim_max_val, idm_dim_min_loc, idm_dim_max_loc = cv2.minMaxLoc(idm_dim_result)
        if idm_max_val >= 0.8:
            x, y = idm_max_loc
            w, h = idm_template.shape[::-1]
            x += w // 2
            y += h // 2
            print("IDM Button Found")
            pg.click(x, y)
            return True
        elif idm_dim_max_val >= 0.8:
            x, y = idm_dim_max_loc
            w, h = idm_dim_template.shape[::-1]
            x += w // 2
            y += h // 2
            print("IDM Dim Button Found")
            pg.click(x, y)
            return True
        else:
            time.sleep(0.1)
            elapsed_time = time.time() - start_time
            if elapsed_time >= 25:
                print("IDM Button Not Found")
                print("Elapsed time exceeded 20 seconds, exiting the loop")
                return False # exit the loop


async def quality():
    video_quality = (settings['quality']).replace("p", "")
    start_time = time.time()
    while True:
        quality_template = cv2.imread('assets/quality_'+video_quality+'.png', cv2.IMREAD_GRAYSCALE)
        screenshot = np.array(pg.screenshot())
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        quality_result = cv2.matchTemplate(gray_screenshot, quality_template, cv2.TM_CCOEFF_NORMED)
        quality_min_val, quality_max_val, quality_min_loc, quality_max_loc = cv2.minMaxLoc(quality_result)
        if quality_max_val >= 0.8:
            x, y = quality_max_loc
            w, h = quality_template.shape[::-1]
            x += w // 2
            y += h // 2
            print("Quality Button Found")
            pg.click(x, y)
            return True     
        else:
            time.sleep(0.1)
            elapsed_time = time.time() - start_time
            if elapsed_time >= 10:
                print("Quality Button Not Found")
                print("Elapsed time exceeded 10 seconds, exiting the loop")
                return False # exit the loop


async def download():
    start_time = time.time()
    while True:
        download_template = cv2.imread('assets/download.png', cv2.IMREAD_GRAYSCALE)
        screenshot = np.array(pg.screenshot())
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        download_result = cv2.matchTemplate(gray_screenshot, download_template, cv2.TM_CCOEFF_NORMED)
        download_min_val, download_max_val, download_min_loc, download_max_loc = cv2.minMaxLoc(download_result)
        if download_max_val >= 0.8:
            x, y = download_max_loc
            w, h = download_template.shape[::-1]
            x += w // 2
            y += h // 2
            print("Download Button Found")
            pg.click(x, y)
            return True     
        else:
            time.sleep(0.1)
            elapsed_time = time.time() - start_time
            if elapsed_time >= 10:
                print("Download Button Not Found")
                print("Elapsed time exceeded 10 seconds, exiting the loop")
                return False # exit the loop


async def next():
    start_time = time.time()
    while True:
        next_template = cv2.imread('assets/next.png', cv2.IMREAD_GRAYSCALE)
        screenshot = np.array(pg.screenshot())
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        next_result = cv2.matchTemplate(gray_screenshot, next_template, cv2.TM_CCOEFF_NORMED)
        next_min_val, next_max_val, next_min_loc, next_max_loc = cv2.minMaxLoc(next_result)
        if next_max_val >= 0.8:
            x, y = next_max_loc
            w, h = next_template.shape[::-1]
            x += w // 2
            y += h // 2
            print("Next Button Found")
            pg.click(x, y)
            time.sleep(1)
            return True     
        else:
            time.sleep(0.1)
            elapsed_time = time.time() - start_time
            if elapsed_time >= 10:
                print("Next Button Not Found")
                print("Elapsed time exceeded 10 seconds, exiting the loop")
                return False # exit the loop


async def finish():
    time.sleep(0.1)
    start_time = time.time()
    while True:
        finish_template = cv2.imread('assets/finish.png', cv2.IMREAD_GRAYSCALE)
        screenshot = np.array(pg.screenshot())
        gray_screenshot = cv2.cvtColor(screenshot, cv2.COLOR_BGR2GRAY)
        finish_result = cv2.matchTemplate(gray_screenshot, finish_template, cv2.TM_CCOEFF_NORMED)
        finish_min_val, finish_max_val, finish_min_loc, finish_max_loc = cv2.minMaxLoc(finish_result)
        if finish_max_val >= 0.8:
            x, y = finish_max_loc
            w, h = finish_template.shape[::-1]
            x += w // 2
            y += h // 2
            print("Finish Button Found")
            pg.click(x, y)
            return True     
        else:
            time.sleep(0.1)
            elapsed_time = time.time() - start_time
            if elapsed_time >= 0.8:
                print("Finished Button Not Found.")
                return False



async def done(message):
    win32api.MessageBox(0, message, "Done", win32con.MB_OK | win32con.MB_ICONINFORMATION)


def logs(e):
    # Create a filename based on the current date and time
    now = datetime.datetime.now()
    filename = f"others/logs/log__{now.strftime('%d-%m-%Y__%H-%M-%S')}.txt"
    os.makedirs("others/logs", exist_ok=True)

    # Open the file and write log data
    with open(filename, "w") as f:
        f.write(f"\nOrigin: update.py\n_______________________________________\n\n{e}")


async def start():
    print("\n\nStarting... \n")
    time.sleep(1)
    starter = False
    print("________________________________ \n")
    try:
        if (await switch()) == False:
            return True

        await fixView()
        start_time_total = time.time()
        while True:
            if keyboard.is_pressed('ctrl') and keyboard.is_pressed('c'):  # if key 'esc' is pressed 
                print("Exiting the program...")
                break  # finishing the loop
            time.sleep(0.5)
            if starter == False:
                starter = True
                if (await play()) == False:
                    break
            if (await idm()) == False:
                break 
            if (await quality()) == False:
                break 
            if (await finish()) == True:
                elapsed_time = time.time() - start_time_total
                print("\n________________________________ \n")
                print("Finished in " + str(int(elapsed_time)) + " seconds.")
                print("DONE.")
                asyncio.create_task(done("Finished in " + str(int(elapsed_time)) + " seconds."))
                break
            if (await download()) == False:
                break 
            if (await next()) == False:
                break 
    except Exception as e: 
        logs(traceback.format_exc())
        win32api.MessageBox(0, f"An unexpected error occurred! Please try again later.\n\n{e}", "Oops, An error occurred", win32con.MB_OK | win32con.MB_ICONSTOP)



async def main():
    await start()


asyncio.run(main())
