import os, json, subprocess, datetime, traceback
import win32api, win32con
import PySimpleGUI as sg

# App Version
version = "1.0"



def logs(e):
    # Create a filename based on the current date and time
    now = datetime.datetime.now()
    filename = f"others/logs/log__{now.strftime('%d-%m-%Y__%H-%M-%S')}.txt"
    os.makedirs("others/logs", exist_ok=True)

    # Open the file and write log data
    with open(filename, "w") as f:
        f.write(f"\nOrigin: update.py\n_______________________________________\n\n{e}")

try:
    # Get the full path to the current directory
    current_dir = os.getcwd()

    # Path to the settings JSON file
    settings_path = os.path.join(current_dir, "others/settings.json")
    # If the settings file doesn't exist, create it with default values
    if not os.path.exists(settings_path):
        default_settings = {
            "browser": "Google Chrome",
            "quality": "720p"
        }
        with open(settings_path, "w") as f:
            json.dump(default_settings, f)
    # Load the settings from the JSON file
    with open(settings_path, "r") as f:
        settings = json.load(f)



    # GUI Theme
    sg.theme('DarkBlue1')
    sg.theme_input_background_color('#161b22')

    # Define the layout
    layout = [
        [sg.VSeperator(30)],
        [sg.Image(filename='assets/icon.png', pad=((0, 0), 0))],
        [sg.Text('9anime Automated Downloader', font=('Helvetica', 20), pad=((0, 0), (0, 10)))],
        [sg.VSeperator(0)],
        [sg.HorizontalSeparator()],
        [sg.VSeperator(0)],
        [sg.Column([[sg.Text('Browser of choice:', font=('Helvetica', 12), size=(15, 1)), sg.Combo(['Google Chrome', 'Mozilla Firefox'], default_value=settings['browser'], font=('Helvetica', 12), size=(20, 1), readonly=True, key='browser_choice', enable_events=True)]], pad=((0, 0), (20, 0)))],
        [sg.VSeperator(10)],
        [sg.Column([[sg.Text('Video Quality:', font=('Helvetica', 12), size=(15, 1)), sg.Combo(['360p', '720p', '1080p'], default_value=settings['quality'], font=('Helvetica', 12), size=(20, 1), readonly=True, key='video_quality', enable_events=True)]])],
        [sg.VSeperator(0)],
        [sg.Button('Start', size=(20, 2), font=('Helvetica', 14), pad=((0, 0), 20), button_color=("black", 'white'))],
        [sg.VSeperator(0)],
        [sg.HorizontalSeparator()],
        [sg.VSeperator(0)],
        [sg.Column([[sg.InputText('', key='dir_path', size=(40, 1), font=('Helvetica', 15), tooltip='Enter Directory Path Here', enable_events=True, justification='center'), sg.FolderBrowse('Browse', size=(10, 1), font=('Helvetica', 12), button_color=("black", 'white'))]], pad=((0, 0), (20, 0)))],
        [sg.VSeperator(20)],
        [sg.Button('Rename', size=(20, 2), font=('Helvetica', 14), pad=((0, 0), (8, 25)), button_color=("black", 'white'))],
        [sg.VSeperator(0)],
        [sg.Column([[sg.Text('Version: '+ version +' [beta]'), sg.Button('  Check for Update  ', button_color=('black', 'grey'), pad=((330, 0), 0), key="update")]])]
    ]

    # Create the window
    window = sg.Window('9anime Automated Downloader', layout, size=(600, 600), element_justification='center')

    # Event loop
    while True:
        event, values = window.read()
        if event == sg.WIN_CLOSED:
            break
        # If the user clicks the "Start" button
        if event == "Start":
            # Run the batch file as a separate process
            subprocess.Popen(os.path.join(current_dir, "scripts/main.bat"), shell=True)
        # If the user clicks the "Rename" button
        if event == "Rename":
            # Run the python file as a separate process
            directory_path = (values['dir_path']).replace('"', '').strip()
            if directory_path != "":
                window['dir_path'].update(directory_path)
                subprocess.Popen(["pyw", "scripts/rename.py", directory_path])
            else:
                win32api.MessageBox(0, 'Directory path is empty. Please enter a valid directory path.', "Bad Directory Path", win32con.MB_OK | win32con.MB_ICONEXCLAMATION)
        # If the user changes the settings
        if event == 'browser_choice' or event == 'video_quality':
            # Load the settings from the JSON file
            with open(settings_path, "r") as f:
                settings = json.load(f)
            settings['browser'] = values['browser_choice']  
            settings['quality'] = values['video_quality']  
            with open(settings_path, "w") as f:
                json.dump(settings, f)
        # If the user clicks the "Check for Update" button
        if event == "update":
            # Run the python file as a separate process
            subprocess.Popen(["pyw", "scripts/update.py", version])
            window.close()

    # Close the window
    window.close()


except Exception as e: 
    logs(traceback.format_exc())
    win32api.MessageBox(0, f"An unexpected error occurred! Please try again later.\n\n{e}", "Oops, An error occurred", win32con.MB_OK | win32con.MB_ICONSTOP)
